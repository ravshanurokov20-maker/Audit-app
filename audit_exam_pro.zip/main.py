from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock
import random

# ⚠️ сюда можно вставить все 300 вопросов
questions = [
    {"q": "Qonun qachon qabul qilingan?", "options": ["2021-yil 25-fevral","2021-yil 24-fevral","2022-yil 25-fevral","2020-yil 10-noyabr"], "answer": 0},
    {"q": "Auditorlar soni nechta?", "options": ["4","5","3","6"], "answer": 0},
]

random.shuffle(questions)

class TestApp(App):
    def build(self):
        self.index = 0
        self.score = 0
        self.time_left = 1800  # 30 минут

        self.layout = BoxLayout(orientation='vertical')

        self.timer = Label(text="")
        self.layout.add_widget(self.timer)

        self.label = Label(text="", size_hint=(1,0.3))
        self.layout.add_widget(self.label)

        self.buttons = []
        for i in range(4):
            btn = Button()
            btn.bind(on_press=self.check)
            self.layout.add_widget(btn)
            self.buttons.append(btn)

        Clock.schedule_interval(self.update_time, 1)
        self.load()
        return self.layout

    def update_time(self, dt):
        self.time_left -= 1
        mins = self.time_left // 60
        secs = self.time_left % 60
        self.timer.text = f"⏱ {mins}:{secs:02d}"

        if self.time_left <= 0:
            self.finish()

    def load(self):
        if self.index >= len(questions):
            self.finish()
            return

        q = questions[self.index]
        self.label.text = f"Savol {self.index+1}: {q['q']}"
        for i in range(4):
            self.buttons[i].text = q["options"][i]
            self.buttons[i].id = str(i)

    def check(self, instance):
        if int(instance.id) == questions[self.index]["answer"]:
            self.score += 1

        self.index += 1
        self.load()

    def finish(self):
        self.layout.clear_widgets()
        self.layout.add_widget(Label(text=f"Natija: {self.score}/{len(questions)}"))

TestApp().run()
