[app]
title = AuditExamPRO
package.name = auditexampro
package.domain = org.audit
source.dir = .
requirements = python3,kivy
orientation = portrait
fullscreen = 1
